const baseURL = 'http://localhost:3000' // Define la URL base de tu API o servidor de datos (json-server en este caso).

export async function get(path) {
    
    try {
      
        const response = await fetch(`${baseURL}${path}`);
        
        const data = await response.json();
        

        return data;
    } catch (err) {
        
        console.error(err); 
    }
}

export async function post(path, obj) {
    
    try {
        
        const response = await fetch(`${baseURL}${path}`, {
            
            method: 'POST', 
            headers: {
                // Define las cabeceras de la solicitud.
                "Content-Type": "application/json" // Indica que el cuerpo de la solicitud es JSON.
            },
            body: JSON.stringify(obj) // Convierte el objeto JavaScript 'obj' a una cadena JSON para enviarlo en el cuerpo.
        });

        if (!response.ok) {
            
            const error_text = await response.text();
            
            throw new Error(`Error ${response.status}: ${error_text}`);
            // Lanza un nuevo error con el estado HTTP y el texto del error.
        }

        const data = await response.json();

        return data; // Retorna los datos del recurso recién creado.
    } catch (error) {
        // Captura cualquier error (incluyendo los lanzados explícitamente).
        console.error("Error en POST:", error.message || error); // Muestra el error en la consola.
        throw error; // Propaga el error para que pueda ser manejado por la función que llamó a 'post'.
    }
}

export async function put(path, id, obj) {
    
    try {
        // Intenta realizar la solicitud.
        const response = await fetch(`${baseURL}${path}/${id}`, {
           
            method: 'PUT', // Define el método HTTP como PUT.
            headers: {
               
                "Content-Type": "application/json" 
            },
            body: JSON.stringify(obj) // Convierte el objeto 'obj' a una cadena JSON para enviarlo.
        });

        if (!response.ok) {
            // Verifica si la respuesta HTTP no fue exitosa.
            const error_text = await response.text();
            throw new Error(`Error ${response.status}: ${error_text}`); // Lanza un nuevo error.
        }

        const data = await response.json();
        
        return data;
    } catch (error) {
        // Captura cualquier error.
        console.error("Error en PUT:", error.message || error); // Muestra el error en la consola.
        throw error; // Propaga el error.
    }
}

export async function deletes(path, id) {
 
    try {
        // Intenta realizar la solicitud.
        const response = await fetch(`${baseURL}${path}/${id}`, {
          
            method: 'DELETE', // Define el método HTTP como DELETE.
        });

        if (!response.ok) {
            // Verifica si la respuesta HTTP no fue exitosa.
            const error_text = await response.text();
            throw new Error(`Error ${response.status}: ${error_text}`); // Lanza un nuevo error.
        }

        const data = await response.json();
     
        return data; 
    } catch (error) {
        // Captura cualquier error.
        console.error("Error en DELETE:", error.message || error); // Muestra el error en la consola.
        throw error; // Propaga el error.
    }
}