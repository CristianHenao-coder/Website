import { deletes, get, post, } from "./services";
// Importa las funciones 'deletes', 'get' y 'post' desde el archivo './services.js'.
// Estas funciones se usarán para interactuar con la API (json-server).

// Seleccionamos el elemento principal donde se mostrará el contenido dinámico
const app = document.getElementById('app');
// Obtiene la referencia al elemento HTML con el ID 'app'.
// Este elemento es el contenedor principal donde se cargarán las diferentes páginas HTML de la aplicación.

//Definimos un objeto con las rutas disponibles y su contenido html asociado
const routes = {
    // Define un objeto JavaScript 'routes' que mapea las rutas de la aplicación
    // (basadas en el hash de la URL) a los archivos HTML correspondientes.
    '/': './pages/inicio.html',             // La ruta raíz (ej. 'http://localhost:5173/#/') carga 'inicio.html'.
    '/iniciar-sesion': './pages/iniciar-sesion.html', // La ruta '/iniciar-sesion' carga 'iniciar-sesion.html'.
    '/create-event': './pages/create-event.html', // La ruta '/registrar-libro' carga 'registrar-libro.html'.
    '/every_events': './pages/every_events.html'        // La ruta '/libros' carga 'libros.html'.
}

// Esta función se encarga de actualizar la vista según la ruta en el hash
function router() {
    // Define la función 'router' que es responsable de cargar el contenido correcto
    // basado en la URL y de aplicar los listeners de eventos.
    const hash = window.location.hash || '#/';
    // Obtiene la parte del "hash" de la URL (ej. '#/iniciar-sesion').
    // Si no hay hash (ej. 'http://localhost:5173/'), por defecto usa '#/'.

    const route = hash.slice(1);
    // Elimina el carácter '#' del principio del hash para obtener solo la ruta limpia
    // (ej. de '#/iniciar-sesion' a '/iniciar-sesion').

    fetch(routes[route])
    
    .then(res => res.text())
    // Una vez que la respuesta del fetch llega, la convierte a texto plano.
    // Esto es necesario porque estamos cargando un archivo HTML.
    .then(data => {
        // 'data' ahora contiene el contenido HTML del archivo.

        const current_user = JSON.parse(localStorage.getItem('user'));
        // Intenta recuperar la información del usuario actualmente logueado desde el localStorage del navegador.
        // `localStorage.getItem('user')` devuelve una cadena JSON o null si no existe.
        // `JSON.parse()` convierte esa cadena JSON de nuevo en un objeto JavaScript.

        if (route === '/iniciar-sesion' && current_user) {
            // Condición de protección de ruta:
            // Si la ruta actual es '/iniciar-sesion' Y ya hay un 'current_user' (está logueado)...
            window.location.hash = '/';
            // ...entonces redirige al usuario a la página de inicio ('/').
            // Esto evita que un usuario ya autenticado vea la página de login.
        }

        if (route === '/create-event' && (!current_user || !current_user.es_user)) {
            // Condición de protección de ruta para 'registrar-libro':
            // Si la ruta actual es '/registrar-libro' Y (NO hay 'current_user' O el 'current_user' NO es bibliotecario)...
            window.location.hash = '/';
            // ...entonces redirige al usuario a la página de inicio ('/').
            // Esto asegura que solo los bibliotecarios autenticados puedan acceder a esta página.
        }

        app.innerHTML = data;
        // Establece el contenido HTML del elemento 'app' (el contenedor principal)
        // con los datos HTML cargados para la ruta actual. Esto "muestra" la nueva página.

        setListeners(route);
        // Llama a la función 'setListeners', pasándole la 'route' actual.
        // Esta función se encargará de adjuntar los manejadores de eventos específicos
        // para los elementos de la página que acaba de ser cargada.
    })
}

//--------------------------------------

async function setListeners(route) {

    if (route === '/iniciar-sesion') {
       
        const formLogin = document.getElementById('login-form');
        // Obtiene la referencia al formulario de inicio de sesión por su ID 'login-form'.

        formLogin.addEventListener('submit', async (e) => {
            // Añade un 'event listener' al formulario 'formLogin' que se activa cuando se envía (submit).
            e.preventDefault(); // Evita el comportamiento predeterminado del navegador de recargar la página al enviar el formulario.

            const email = document.getElementById('email').value;
            // Obtiene el valor (texto) del campo de entrada con ID 'email'.
            const password = document.getElementById('password').value;
            // Obtiene el valor (texto) del campo de entrada con ID 'password'.

            // Obtener todos los usuarios de la "base de datos"
            const usuarios = await get('/usuarios');
            
            const usuarioExistentePorCorreo = usuarios.find(usuario => usuario.correo === email);
            

            if (usuarioExistentePorCorreo) {
               
                if (usuarioExistentePorCorreo.contrasena === password) {
                    
                    localStorage.setItem('user', JSON.stringify(usuarioExistentePorCorreo));
                
                    alert(`¡Bienvenido de nuevo, ${usuarioExistentePorCorreo.nombre}!`);
                    
                    window.location.hash = '/'; // Redirige al usuario a la página de inicio ('/').
                } else {
                    // 3. ...pero la contraseña es INCORRECTA: Muestra un error específico
                    alert('Error en contraseña. Vuelve a intentarlo.');
                    // Muestra una alerta indicando que la contraseña es incorrecta.
                    document.getElementById('password').value = ''; // Opcional: Limpia el contenido del campo de la contraseña.
                }
            } else {
                
                const nuevoUsuario = {
                   
                    nombre: email.split('@')[0], 
                    correo: email,               // Asigna el correo electrónico ingresado.
                    contrasena: password,        
                    es_user: true       
                                                 
                };

                await post('/usuarios', nuevoUsuario)
                    // Llama a la función 'post' (importada de services.js) para enviar los datos del 'nuevoUsuario'
                    // al endpoint '/usuarios' de la API, lo que lo agrega a la base de datos.
                    .then(response => {
                        
                        alert(`¡Bienvenido, ${nuevoUsuario.nombre}! Usuario registrado y sesión iniciada.`);
                        // Muestra una alerta confirmando el registro y el inicio de sesión.
                        localStorage.setItem('user', JSON.stringify(response));
                        // Guarda el objeto del nuevo usuario (incluyendo el ID asignado por el servidor) en localStorage.
                        window.location.hash = '/'; // Redirige al usuario a la página de inicio ('/').
                    })
                    .catch(error => {
                        // Esta parte se ejecuta si la solicitud POST falla por alguna razón.
                        console.error('Error al registrar el usuario:', error);
                        // Muestra el error detallado en la consola del navegador para depuración.
                        alert('Hubo un error al intentar registrar el usuario.');
                       
                    });
            }
        });
    }

    // ... (el resto de tu función setListeners para otras rutas, como '/registrar-libro' y '/libros', permanece igual)
    // Este comentario indica que la siguiente sección de código (para '/registrar-libro') es parte de la misma función setListeners.
    // Se repite un bloque para '/registrar-libro', lo que podría ser una copia accidental o una decisión de diseño.
    // Si la lógica es la misma, uno de los bloques es redundante.

    if (route === '/create-event') {
        // Bloque de código que se ejecuta solo cuando la ruta actual es '/registrar-libro'.
        const formRegisterBook = document.getElementById('register-book-form');
        // Obtiene la referencia al formulario de registro de libros por su ID.

        formRegisterBook.addEventListener('submit', async (e) => {
            // Añade un 'event listener' al formulario 'formRegisterBook' para el evento 'submit'.
            e.preventDefault(); // Evita el comportamiento predeterminado del navegador.

            const name = document.getElementById('name').value;
            // Obtiene el valor del campo 'name' (nombre del libro).
            const description = document.getElementById('description').value;
            // Obtiene el valor del campo 'author' (autor del libro).
            const capacity = document.getElementById('capacity').value;
            // Obtiene el valor del campo 'year' (año del libro).

            const event = { name:name, description:description, capacity:capacity };
            // Crea un objeto 'book' con los datos recopilados del formulario.

            await post('/eventos', event)
            // Llama a la función 'post' (de services.js) para enviar el objeto 'book'
            // al endpoint '/libros' de la API, registrando un nuevo libro.
            .then(() => {
                // Esta parte se ejecuta si la solicitud POST es exitosa.
                alert('Se subio tu evento!') // Muestra una alerta de confirmación.
                window.location.hash = '/every_events'; // Redirige al usuario a la página que lista los libros.
            })
        })
    }


    if (route === '/every_events') {
        // Bloque de código que se ejecuta solo cuando la ruta actual es '/libros'.
        const template = document.getElementById('user-table-template');
        // Obtiene la referencia a un elemento de plantilla HTML (probablemente un <template>
        // que contiene la estructura de una fila de tabla para un libro).
        const table = document.querySelector('tbody');
        // Obtiene la referencia al elemento `<tbody>` de la tabla donde se insertarán los datos.

        table.innerHTML = '';
        // Limpia cualquier contenido existente dentro del `<tbody>`.
        // Esto es importante para evitar duplicados si la página se recarga o se vuelve a visitar la ruta.

        const eventos = await get( '/eventos'  );
        // Llama a la función 'get' (de services.js) para obtener todos los 'libros' del endpoint '/libros'.
        // NOTA: La variable se llama 'users', pero el 'route' es '/libros', y el uso posterior es para libros.
        // Esto sugiere que 'users' debería ser 'libros' para mayor claridad.

        eventos.forEach(event => {
            // Itera sobre cada 'user' (que en realidad es un 'libro' en este contexto) obtenido de la API.
            let clone = document.importNode(template.content, true);
            // Clona el contenido del template (la estructura de la fila de la tabla).
            // `true` asegura que también se clonen los elementos hijos del template.
            let td = clone.querySelectorAll('td');
            // Obtiene todos los elementos `<td>` (celdas de la tabla) dentro del clon de la fila.

            td[0].textContent = event.name;   // Asigna el 'name' del libro a la primera celda.
            td[1].textContent = event.descripcion; // Asigna el 'author' del libro a la segunda celda.
            td[2].textContent = event.capacity;   // Asigna el 'year' del libro a la tercera celda.

            

            const btn = document.createElement('button');
            // Crea un nuevo elemento HTML `<button>`.
            btn.textContent = 'Eliminar'; // Establece el texto visible del botón como 'Eliminar'.
            btn.addEventListener('click', () => {
                // Añade un 'event listener' al botón para que cuando se haga clic en él...
                deletes(route, event.id);
                // ...llame a la función 'deletes' (de services.js) para eliminar el libro
                // usando la ruta actual ('/libros') y el 'id' del libro específico.

                alert(`Se borro exitosamente a ${event.name}`);
                // Muestra una alerta confirmando la eliminación del libro.
                window.location.reload();
                // Recarga la página completa del navegador. Esto es una forma sencilla
                // de actualizar la tabla después de una eliminación, aunque no es la más eficiente
                // (una alternativa sería eliminar la fila del DOM directamente).
            })
            table.appendChild(clone);

            td[3].appendChild(btn);
            // Añade el botón "Eliminar" como hijo a la cuarta celda `<td>` (columna de Acciones).

            table.appendChild(clone);
            // Añade el clon de la fila (con todos sus datos y el botón) al `<tbody>` de la tabla,
            // haciéndolo visible en la página.
        })
    }
}

window.addEventListener('load', router);
// Añade un 'event listener' al objeto global 'window'.
// Cuando el evento 'load' (la página y todos sus recursos se han cargado) ocurre,
// la función 'router' se ejecuta. Esto carga la página inicial.

window.addEventListener('hashchange', router);
// Añade un 'event listener' al objeto global 'window'.
// Cuando el evento 'hashchange' (la parte del hash de la URL cambia) ocurre,
// la función 'router' se ejecuta. Esto permite la navegación SPA (Single Page Application)
// sin recargar la página completa.