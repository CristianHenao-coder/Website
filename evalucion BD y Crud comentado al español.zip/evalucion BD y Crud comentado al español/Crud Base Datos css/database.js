// (Backend) — connection to a pool of MySQL connections

import mysql from "mysql2/promise";


const pool = mysql.createPool({
  host: "localhost",   
  user: "root",       
  password: "Qwe.123*",        
  database: "Bibliosoft" 
});

//You export the pool to use it in index.js
export default pool;
