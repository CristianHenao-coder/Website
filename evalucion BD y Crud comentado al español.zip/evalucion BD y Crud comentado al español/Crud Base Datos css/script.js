//script.js (Frontend) — CRUD logic in the browser

//You expose a global function that the router invokes when it enters /crud.
//Inside you hook events, load tables, etc.

window.initCrud = function(){
 
  const apiURL = "http://localhost:3000/usuarios";


  async function cargarUsuarios() {

    const res = await fetch(apiURL);
    const usuarios = await res.json();

 
    const tbody = document.getElementById("tablaUsuarios");
    if (!tbody) return;

  
    tbody.innerHTML = "";
    usuarios.forEach(u => {

      tbody.innerHTML += `
        <tr>
          <td>${u.id}</td>
          <td>${u.nombre}</td>
          <td>${u.identificacion}</td>
          <td>${u.direccion || ""}</td>
          <td>${u.telefono || ""}</td>
          <td>${u.correo || ""}</td>
          <td>
            <button onclick="editarUsuario(${u.id})">Editar</button>
            <button onclick="eliminarUsuario(${u.id})">Eliminar</button>
          </td>
        </tr>
      `;
    });
  }

 
  window.cargarUsuarios = cargarUsuarios;


  const formCrear = document.getElementById("formCrear");
  if (formCrear){
   
    formCrear.addEventListener("submit", async e => {
      e.preventDefault(); // Evitas recarga de página.

      
      const data = Object.fromEntries(new FormData(e.target));

     
      const resp = await fetch(apiURL, {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify(data)
      });

    
      if(!resp.ok){ alert("Error al crear"); return; }

     
      e.target.reset();
      cargarUsuarios();
    });
  }

  
  window.editarUsuario = async function (id) {
    // GET /usuarios/:id
    const res = await fetch(`${apiURL}/${id}`);
    const u = await res.json();


    const form = document.getElementById("formEditar");
    if(!form) return;
    form.style.display = "block";

    //You map the form fields with the received values.
    form.id.value = u.id;
    form.nombre.value = u.nombre;
    form.identificacion.value = u.identificacion;
    form.direccion.value = u.direccion || '';
    form.telefono.value = u.telefono || '';
    form.correo.value = u.correo || '';
  };

  // --- UPDATE: Send changes from #formEditar to PUT /users/:id ---
  const formEditar = document.getElementById("formEditar");
  if (formEditar){
    formEditar.addEventListener("submit", async e => {
      e.preventDefault();

      
      const data = Object.fromEntries(new FormData(e.target));


      const id = data.id;
      delete data.id;

      
      const resp = await fetch(`${apiURL}/${id}`, {
        method:"PUT",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify(data)
      });

      if(!resp.ok){ alert("Error al actualizar"); return; }

    
      e.target.style.display = "none";
      cargarUsuarios();
    });
  }


  window.eliminarUsuario = async function (id) {
 
    if (!confirm("¿Seguro que deseas eliminar este usuario?")) return;

  
    await fetch(`${apiURL}/${id}`, { method: "DELETE" });

   
    cargarUsuarios();
  };


  if (document.getElementById("tablaUsuarios")) cargarUsuarios();
};

if (document.getElementById("tablaUsuarios")) window.initCrud();
