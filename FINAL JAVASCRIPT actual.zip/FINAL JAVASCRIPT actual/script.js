import { deletes, get, post, put } from "./services"; // Importa funciones de la API

const app = document.getElementById('app'); // Contenedor principal de la app

// Define las rutas y sus archivos HTML correspondientes
const routes = {
    '/': './pages/inicio.html',
    '/iniciar-sesion': './pages/iniciar-sesion.html',
    '/create-event': './pages/create-event.html',
    '/every_events': './pages/every_events.html',
    '/editar': './pages/editar.html',
    '/Registrarse': './pages/registrarse.html',
    '/cerrar_session': null, // Ruta para cerrar sesión (no carga un HTML, solo ejecuta lógica)
};

// Función principal que maneja el cambio de rutas
async function router() {
    const hash = window.location.hash || '#/'; // Obtiene la ruta del hash
    const route = hash.slice(1); // Elimina el '#'

    if (route === 'cerrar_session') {
        cerrarSession();
        return;
    }

    const path = routes[route];
    if (!path && route !== 'cerrar_session') {
        app.innerHTML = `<h1>Página no encontrada</h1><p>La ruta "${route}" no existe.</p>`;
        return;
    }

    try {
        const res = await fetch(path);
        if (!res.ok) throw new Error('Error al cargar la página');
        const data = await res.text();

        const current_user = JSON.parse(localStorage.getItem('user'));
        const cerrarLink = document.getElementById('cerrarSessionLink');
        if (cerrarLink) {
        cerrarLink.style.display = current_user ? 'inline' : 'none';
}

        // Redirección si ya está logueado y va a login
       if ((route === '/iniciar-sesion' || route === '/Registrarse') && current_user) {
        alert("Ya has iniciado sesión.");
        window.location.hash = '/';
        return;
}

        // Protección de ruta para crear eventos (solo admin)
        if (route === '/create-event' && (!current_user || current_user.rol !== 'admin')) {
            alert("Acceso denegado. Solo administradores pueden crear eventos.");
            window.location.hash = '/';
            return;
        }

        app.innerHTML = data; // Inyecta el HTML en la app
        await setListeners(route); // Adjunta los eventos a la nueva página

    } catch (error) {
        console.error('Error al cargar la ruta:', error);
        app.innerHTML = `<h1>Error al cargar la página: ${route}</h1><p>Por favor, verifica la ruta y el archivo HTML.</p>`;
    }
}

// Adjunta el listener para cerrar sesión en el link si existe (en el DOM raíz)
document.addEventListener('DOMContentLoaded', () => {
    const cerrarSessionLink = document.getElementById('cerrarSessionLink');
    if (cerrarSessionLink) {
        cerrarSessionLink.addEventListener('click', (e) => {
            e.preventDefault();
            cerrarSession();
        });
    }
});


// OCULTAR boton de cerrar session 

const current_user = JSON.parse(localStorage.getItem('user'));
const cerrarLink = document.getElementById('cerrarSessionLink');
if (!current_user && cerrarLink) {
    cerrarLink.style.display = 'none'; // Oculta si no hay usuario
}


// Función para cerrar la sesión del usuario
function cerrarSession() {
    if (confirm("¿Está seguro que quiere cerrar sesión?")) {
        localStorage.removeItem('user'); // ❌ Elimina solo el usuario
        // o usa localStorage.clear(); si quieres limpiar todo

        alert("Sesión cerrada exitosamente.");
        window.location.hash = '/';
        window.location.reload(); // 🔁 Fuerza la recarga para aplicar cambios
    }
}



// Función para adjuntar listeners a los elementos de cada página
async function setListeners(route) {
    if (route === '/Registrarse') {
        const formregistro = document.getElementById('Register');
        if (!formregistro) return;

        formregistro.addEventListener('submit', async (e) => {
            e.preventDefault();

            const nombre = document.getElementById('Nombre').value.trim();
            const correo = document.getElementById('correoelectronico').value.trim();
            const Contraseña = document.getElementById('Contraseña').value;
            const confirmarpasword = document.getElementById('correctpassword').value;
            const rolselecionado = document.querySelector('input[name="rol"]:checked');

            if (!rolselecionado) {
                alert("Por favor, seleccione una de las opciones de rol.");
                return;
            }
            const rol = rolselecionado.value;

            if (Contraseña !== confirmarpasword) {
                alert("Las contraseñas no coinciden. Intente de nuevo.");
                document.getElementById('Contraseña').value = '';
                document.getElementById('correctpassword').value = '';
                return;
            }

            const nuevoUsuario = { nombre, correo, contrasena: Contraseña, rol };

            try {
                const usuariosExistentes = await get('/usuarios');
                if (usuariosExistentes.some(u => u.correo === correo)) {
                    alert("Este correo ya está registrado.");
                    return;
                }

                const usuarioRegistrado = await post('/usuarios', nuevoUsuario);
                localStorage.setItem('user', JSON.stringify(usuarioRegistrado));

                alert("Registro exitoso. ¡Bienvenido!");
                window.location.hash = "/";

            } catch (error) {
                console.error('Error al registrar usuario:', error);
                alert('Error al registrar. Por favor, intente de nuevo.');
            }
        });
    }

    if (route === '/iniciar-sesion') {
        const formLogin = document.getElementById('login-form');
        if (!formLogin) return;

        formLogin.addEventListener('submit', async (e) => {
            e.preventDefault();

            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;

            try {
                const usuarios = await get('/usuarios');
                const usuario = usuarios.find(u => u.correo === email);

                if (usuario) {
                    if (usuario.contrasena === password) {
                        localStorage.setItem('user', JSON.stringify(usuario));
                        alert(`¡Bienvenido de nuevo, ${usuario.nombre}!`);
                        window.location.hash = '/';

                    // Mostrar el botón "Cerrar Session" dinámicamente
                        const cerrarLink = document.getElementById('cerrarSessionLink');
                        if (cerrarLink) {
                        cerrarLink.style.display = 'inline';
}



                    } else {
                        alert('Contraseña incorrecta. Vuelve a intentarlo.');
                        document.getElementById('password').value = '';
                    }
                } else {
                    alert('Usuario no encontrado. Por favor, regístrese o verifique su correo.');
                }
            } catch (error) {
                console.error('Error al iniciar sesión:', error);
                alert('Hubo un error al intentar iniciar sesión.');
            }
        });
    }


    // Crear Evento -------------------------

    if (route === '/create-event') {
        const formCreateEvent = document.getElementById('register-book-form');
        if (!formCreateEvent) return;

        formCreateEvent.addEventListener('submit', async (e) => {
            e.preventDefault();

            const name = document.getElementById('name').value.trim();
            const description = document.getElementById('description').value.trim();
            const capacity = document.getElementById('capacity').value.trim();

            if (!name || !description || !capacity) {
                alert("Todos los campos son obligatorios.");
                return;
            }
            if (isNaN(Number(capacity)) || Number(capacity) <= 0) {
                alert("La capacidad debe ser un número positivo.");
                return;
            }

            const newEvent = { name, description, capacity: Number(capacity) };

            try {
                await post('/eventos', newEvent);
                alert('¡Evento creado exitosamente!');
                window.location.hash = '/every_events';
            } catch (error) {
                console.error('Error al crear evento:', error);
                alert('Hubo un error al crear el evento. Intente de nuevo.');
            }
        });
    }

    // todos los eventos 
    
    if (route === '/every_events') {
  const template = document.getElementById('user-table-template');
  const tableBody = document.querySelector('tbody');
  if (!tableBody || !template) return;

  tableBody.innerHTML = ''; // Limpia la tabla

  try {
    const eventos = await get('/eventos'); // Obtiene eventos

    if (eventos.length === 0) {
      const noEventsRow = document.createElement('tr');
      noEventsRow.innerHTML = '<td colspan="4">No hay eventos registrados.</td>';
      tableBody.appendChild(noEventsRow);
      return;
    }

    eventos.forEach(event => {
      const clone = document.importNode(template.content, true);
      const td = clone.querySelectorAll('td');

      td[0].textContent = event.name;
      td[1].textContent = event.description;
      td[2].textContent = event.capacity;

      const currentUser = JSON.parse(localStorage.getItem('user'));
      



      //--------------- user boton contador 

   if (currentUser && currentUser.rol === 'user') {
    const joinButton = document.createElement('button');
    joinButton.textContent = 'Unirse';
    joinButton.className = 'unirse-btn';

    if (event.capacity <= 0) {
        joinButton.disabled = true;
        joinButton.textContent = 'Lleno';
    }

    joinButton.addEventListener('click', async () => {
        if (event.capacity <= 0) {
            alert("Lo sentimos, el evento está lleno.");
            return;
        }
        try {
            const updatedEvent = {
                name: event.name,
                description: event.description,
                capacity: event.capacity - 1
            };
            const res = await put('/eventos', event.id, updatedEvent);
            console.log('Respuesta put:', res);
            alert(`Te uniste al evento "${event.name}". Capacidad ahora: ${res.capacity}`);
            router();
        } catch (e) {
            console.error('Error en put unirse:', e);
            alert('Error al intentar unirte al evento.');
        }
    });

    td[3].appendChild(joinButton);
}




      //---------------------------------------

      if (currentUser && currentUser.rol === 'admin') {
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Eliminar';
        deleteButton.className = 'eliminar-btn';

        const editButton = document.createElement('button');
        editButton.textContent = 'Editar';
        editButton.className = 'editar-btn';

        td[3].appendChild(editButton);
        td[3].appendChild(deleteButton);

        // ❌ Eliminar
        deleteButton.addEventListener('click', async () => {
          if (confirm(`¿Estás seguro de que quieres eliminar el evento "${event.name}"?`)) {
            try {
              await deletes('/eventos', event.id);
              alert(`Evento "${event.name}" eliminado exitosamente.`);
              router();
            } catch (error) {
              console.error('Error al eliminar evento:', error);
              alert('Error al eliminar el evento.');
            }
          }
        });

        // ✏️ Editar inline
        editButton.addEventListener('click', () => {
          const tr = editButton.closest('tr');
          const td = tr.querySelectorAll('td');

          td[0].innerHTML = `<input type="text" value="${event.name}" />`;
          td[1].innerHTML = `<input type="text" value="${event.description}" />`;
          td[2].innerHTML = `<input type="number" min="1" value="${event.capacity}" />`;

          td[3].innerHTML = '';

          const saveButton = document.createElement('button');
          saveButton.textContent = 'Guardar';
          saveButton.className = 'guardar-btn';

          const cancelButton = document.createElement('button');
          cancelButton.textContent = 'Cancelar';
          cancelButton.className = 'cancelar-btn';

          td[3].appendChild(saveButton);
          td[3].appendChild(cancelButton);

          // ✅ Guardar
          saveButton.addEventListener('click', async () => {
            const updatedName = td[0].querySelector('input').value.trim();
            const updatedDesc = td[1].querySelector('input').value.trim();
            const updatedCap = td[2].querySelector('input').value.trim();

            if (!updatedName || !updatedDesc || !updatedCap || isNaN(updatedCap) || updatedCap <= 0) {
              alert('Por favor, completa todos los campos correctamente.');
              return;
            }

            try {
              await put('/eventos', event.id, {
                name: updatedName,
                description: updatedDesc,
                capacity: Number(updatedCap)
              });

              alert('Evento actualizado correctamente.');
              router();
            } catch (error) {
              console.error('Error al actualizar evento:', error);
              alert('No se pudo actualizar el evento.');
            }
          });

          // ❌ Cancelar
          cancelButton.addEventListener('click', () => {
            td[0].textContent = event.name;
            td[1].textContent = event.description;
            td[2].textContent = event.capacity;
            td[3].innerHTML = '';
            td[3].appendChild(editButton);
            td[3].appendChild(deleteButton);
          });
        });
      }

      tableBody.appendChild(clone);
    });

  } catch (error) {
    console.error('Error al cargar eventos:', error);
    tableBody.innerHTML = '<tr><td colspan="4">Error al cargar los eventos.</td></tr>';
  }

// usuario botnoes de unirse 



}

    
};

// Escuchadores para el router
window.addEventListener('load', router);
window.addEventListener('hashchange', router);
