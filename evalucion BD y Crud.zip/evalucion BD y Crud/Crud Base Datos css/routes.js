
 //routes.js (type="module") — no roles, with nav visibility control

//References to shell DOM elements (index.html)
const $app    = document.getElementById('app');                
const $logout = document.getElementById('cerrarSessionLink');
const $navLogin    = document.getElementById('navLogin');      
const $navRegister = document.getElementById('navRegister');   
const $navCrud     = document.getElementById('navCrud');      


// isAuth: Returns true if an "auth" key exists in localStorage.
const isAuth  = () => !!localStorage.getItem('auth');

//setAuth: Saves the user object to localStorage and updates the menu.
const setAuth = (u) => { localStorage.setItem('auth', JSON.stringify(u)); updateNav(); };

//logout: delete the session and update menu.
const logout  = () => { localStorage.removeItem('auth'); updateNav(); };

//Show/hide header buttons based on session status.
function updateNav(){
  const auth = isAuth();
  if ($logout)      $logout.style.display = auth ? 'inline-block' : 'none';
  if ($navLogin)    $navLogin.style.display = auth ? 'none' : 'inline-block';
  if ($navRegister) $navRegister.style.display = auth ? 'none' : 'inline-block';
  if ($navCrud)     $navCrud.style.display = auth ? 'inline-block' : 'none';
}

// ---- view paths (partial HTML files) ----
const VIEWS = {
  login:    'pages/iniciar-sesion.html', 
  register: 'pages/registrarse.html',   
  crud:     'formulario.html'            
};

// ---- base router (hash) ----
//routeNow: Normalizes the current hash to "/path"
function routeNow(){ return ('/' + (location.hash.replace(/^#\/?/, '') || '')).toLowerCase(); }


function go(path){ location.hash = path; }


async function load(view, after){
  const res = await fetch(view, { cache: 'no-cache' });
  if (!res.ok){

    $app.innerHTML = `<p style="color:#b91c1c;padding:16px">Vista no encontrada: <code>${view}</code></p>`;
    console.error('404 view', view);
    return;
  }

  $app.innerHTML = await res.text();
 
  after?.();
}

// ---- LOGIN ----
// Vincula el submit del form de login: valida contra "users" en localStorage.
function bindLogin(){
  const form = document.getElementById('login-form');
  if (!form) return;
  form.addEventListener('submit', (e)=>{
    e.preventDefault();

    const email = document.getElementById('email').value.trim().toLowerCase();
    const password = document.getElementById('password').value;

   
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    const user = users[email];

   
    if (!user || user.password !== password){
      alert('Correo o contraseña incorrectos');
      return;
    }

  
    setAuth({ email, nombre: user.nombre });
    updateNav();
    go('/crud');
  });
}


function bindRegister(){
  const form = document.getElementById('Register');
  if (!form) return;
  form.addEventListener('submit', (e)=>{
    e.preventDefault();


    const nombre = document.getElementById('Nombre').value.trim();
    const correo = document.getElementById('correoelectronico').value.trim().toLowerCase();
    const pass   = document.getElementById('Contraseña').value;
    const pass2  = document.getElementById('correctpassword').value;

    if (pass.length < 6) { alert('La contraseña debe tener al menos 6 caracteres'); return; }
    if (pass !== pass2)  { alert('Las contraseñas no coinciden'); return; }

  
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    if (users[correo]) { alert('Ese correo ya está registrado'); return; }

   
    users[correo] = { nombre, password: pass };
    localStorage.setItem('users', JSON.stringify(users));

    
    setAuth({ email: correo, nombre });
    updateNav();
    go('/crud');
  });
}

// ---- CRUD ----
// Cuando se carga la vista CRUD, enganchas la lógica del archivo script.js
function bindCrud(){
  
  if (typeof window.initCrud === 'function') window.initCrud();
  
  else if (typeof window.cargarUsuarios === 'function') window.cargarUsuarios();
}


const routes = {

  '/':               () => go(isAuth() ? '/crud' : '/iniciar-sesion'),


  '/iniciar-sesion': () => {
    if (isAuth()) return go('/crud');
    load(VIEWS.login, bindLogin);
  },

  // Registro: igual que login, bloquea si ya hay sesión.
  '/registrarse':    () => {
    if (isAuth()) return go('/crud');
    load(VIEWS.register, bindRegister);
  },

  
  '/crud':           () => {
    if (!isAuth()) return go('/iniciar-sesion');
    load(VIEWS.crud, bindCrud);
  },

 
  '/cerrar_session': () => {
    logout();
    updateNav();
    go('/iniciar-sesion');
  }
};


window.addEventListener('hashchange', ()=>{
  updateNav();
  (routes[routeNow()] || routes['/'])();
});


window.addEventListener('DOMContentLoaded', ()=>{
  updateNav();
  (routes[routeNow()] || routes['/'])();
});
