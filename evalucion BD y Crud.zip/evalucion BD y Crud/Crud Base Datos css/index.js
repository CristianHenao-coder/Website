//  (Backend) — servidor Express + rutas REST

import express from 'express';       //Node web framework to create the HTTP server.
import pool from './database.js';    //MySQL connection pool (database.js file).
import cors from "cors";             //Middleware to allow CORS (calls from another source).

import path from "path";             //File path utilities (to serve static//File path utilities (to serve static if you want).os if you want).
import { fileURLToPath } from "url"; //To obtain __dirname in ES modules.

const __filename = fileURLToPath(import.meta.url); //Path of the current file (index.js).
const __dirname = path.dirname(__filename);        //Folder where index.js is.

const app = express();

//Serves /public if it exists. (It is not mandatory; it does not break if it does not exist).
app.use(express.static(path.join(__dirname, "public")));


app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.use(cors({
  origin: "*" 
}));



app.post("/usuarios", async (req, res) => {
  const { nombre, identificacion, direccion, telefono, correo } = req.body;

  const [result] = await pool.query(
    "INSERT INTO usuarios (nombre, identificacion, direccion, telefono, correo) VALUES (?, ?, ?, ?, ?)",
    [nombre, identificacion, direccion, telefono, correo]
  );

 
  res.json({ id: result.insertId, nombre, identificacion, direccion, telefono, correo});
});

// -----------------------------
// READ ALL: GET /usuarios
// -----------------------------
app.get("/usuarios", async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM usuarios");
  res.json(rows);
});

// -----------------------------
// READ ONE: GET /usuarios/:id

// -----------------------------
app.get("/usuarios/:id", async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM usuarios WHERE id = ?", [req.params.id]);
  if (rows.length === 0) return res.status(404).json({ message: "User not found" });
  res.json(rows[0]);
});

// -----------------------------
// UPDATE: PUT /usuarios/:id
// -----------------------------
app.put("/usuarios/:id", async (req, res) => {
  const { nombre, identificacion, direccion, telefono, correo } = req.body;

  const [result] = await pool.query(
    "UPDATE usuarios SET nombre = ?, identificacion = ?, direccion = ?, telefono = ?, correo = ? WHERE id = ?",
    [nombre, identificacion, direccion, telefono, correo, req.params.id]
  );

  res.json({ changedRows: result.affectedRows });
});

// -----------------------------
// DELETE: DELETE /usuarios/:id
// -----------------------------
app.delete("/usuarios/:id", async (req, res) => {
  const [result] = await pool.query("DELETE FROM usuarios WHERE id = ?", [req.params.id]);
  res.json({ deletedRows: result.affectedRows });
});

// Inicia el servidor en el puerto 3000.
app.listen(3000, () => console.log("Servidor en http://localhost:3000"));
