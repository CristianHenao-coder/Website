CREATE DATABASE IF NOT EXISTS Bibliosoft;
USE Bibliosoft;



CREATE TABLE usuarios (
   id INT AUTO_INCREMENT PRIMARY KEY,
    nombre TEXT,
    identificacion  VARCHAR(30) NOT NULL,
    direccion VARCHAR(250),
    telefono VARCHAR(25) NULL,
    correo VARCHAR(50)
    
);


CREATE TABLE libros (
    isbn VARCHAR(13) PRIMARY KEY, 
    titulo VARCHAR(200) NOT NULL,
    autor VARCHAR(100),
    año_publicacion YEAR
);


CREATE TABLE prestamos (
    id_prestamo INT PRIMARY KEY AUTO_INCREMENT,
    id INT NOT NULL,
    isbn VARCHAR(13) NOT NULL,
    fecha_hora_prestamo DATETIME,
    dias_prestamo INT NOT NULL,
    tipo_prestamo ENUM('Préstamo a domicilio', 'Consulta en sala', 'Préstamo interbibliotecario'),
    plataforma_reserva ENUM("webbiblioteca", "appbiblioteca"),
    estado ENUM('completado', 'pendiente', 'retraso'),
    FOREIGN KEY (id) REFERENCES usuarios(id),
    FOREIGN KEY (isbn) REFERENCES libros(isbn)
);


CREATE TABLE devoluciones (
    id_devolucion INT PRIMARY KEY AUTO_INCREMENT,
    id_prestamo INT NOT NULL UNIQUE, 
    fecha_devolucion DATETIME,
    multa_generada INT NOT NULL,
    multa_pagada INT NOT NULL,
    FOREIGN KEY (id_prestamo) REFERENCES prestamos(id_prestamo) ON DELETE CASCADE

);   



-----------------------------------------------------------//------------------------------------------------------

-- 1. "cuántos libros ha prestado cada usuario, para llevar control de los préstamos y detectar usuarios con más actividad."

-- Usa LEFT JOIN para incluir también usuarios que no han hecho ningún préstamo.

SELECT 
    u.id,
    u.nombre,
    u.identificacion,
    COUNT(p.id_prestamo) AS total_libros_prestados
FROM 
    usuarios u
LEFT JOIN 
    prestamos p ON u.id = p.id
GROUP BY 
    u.id, u.nombre, u.identificacion
ORDER BY 
    total_libros_prestados DESC;   



--3. Libros por autor (con disponibilidad)
-- ver todos los libros de un autor específico, junto con su año de publicación y disponibilidad."

Nota: Como no hay campo de disponibilidad directo, se considera disponible si el libro no está en un préstamo pendiente o vencido.

-SELECT 
    l.isbn,
    l.titulo,
    l.autor,
    l.año_publicacion,
    CASE 
        WHEN p.id_prestamo IS NULL THEN 'Disponible'
        WHEN p.estado = 'completado' THEN 'Disponible'
        ELSE 'No disponible'
    END AS disponibilidad
FROM 
    libros l
LEFT JOIN 
    prestamos p ON l.isbn = p.isbn AND p.estado = 'pendiente'
WHERE 
    l.autor LIKE '%García Márquez%' -- ← Cambiar por el autor deseado
ORDER BY 
    l.titulo;   


-------------------------------------------


-- Ver todos los datos de una tabla
SELECT * FROM usuarios;

-- Ver datos específicos
SELECT columna1, columna2 FROM nombre_tabla;

-- Filtrar datos
SELECT * FROM nombre_tabla WHERE columna = 'valor';
