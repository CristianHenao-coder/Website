This system allows you to manage data stored in a MySQL database. 
Simple app with Node.js + Express + MySQL and HTML/CSS/JS front (router with #/path).
Allows you to register/log in (localStorage) and CRUD users.




1) Backend
# si partes desde cero
npm init -y
--
npm install express mysql2 cors
npm install -D nodemon

make sure your package.json is correct
package.json:


  "scripts": {
    "dev": "nodemon ./src/index.js",
    "test": "echo \"Error: no test specified\" && exit 1"
  },{
  "keywords": [],
  "author": "",
  "license": "ISC",
  "type": "module",}
  


and finally run  " npm run dev "

2) Database Configuration
Create a database in MySQL.
Import the SQL script with the structure and initial data.
Configure the connection credentials in a .env file:

DB_HOST=localhost
DB_USER=root
DB_PASSWORD=Qwe.123*
DB_NAME= Bibliosoft
PORT=3000

Technologies Used

MySQL – Relational database engine.
Node.js – JavaScript runtime environment.
MySQL2 – Library for connecting Node.js to MySQL.
Express – Framework for creating APIs and managing routes.
CORS – Middleware for enabling cross-domain requests.




Capturing the relational model

![alt text](image-2.png)



Base de Datos MYSQL 

Database Normalization This project applies database normalization up to Third Normal Form (1NF, 2NF, and 3NF).

1NF (First Normal Form): All columns in the table contain atomic (indivisible) values, and there are no repeating groups.

2NF (Second Normal Form): All non-key attributes are completely dependent on the table's primary key, avoiding partial dependencies.

3NF (Third Normal Form): All attributes depend solely on the primary key, eliminating any transitive dependencies.


Creación de tablas: Mysql Workbench 

CRUD 

![alt text](image.png)
![alt text](image-1.png)





Proyect_Bibliosoft

Cristian Henao P.
LINUX- RIWI 
Cristiancloser7@gmail.com
