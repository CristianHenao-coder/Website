// Este archivo es el director de tráfico de tu aplicación de una sola página (SPA - Single Page Application). Su trabajo es mirar la URL (específicamente la parte después del #), decidir qué vista HTML mostrar, cargarla en el <div id="app"> y ejecutar el código JavaScript necesario para esa vista. También maneja el estado de la sesión (si el usuario ha iniciado sesión o no).




// routes.js — Maneja las rutas del frontend y la visibilidad de la navegación.

// --- REFERENCIAS A ELEMENTOS DEL DOM ---
// Guardamos en constantes las referencias a los elementos HTML de 'index.html' que vamos a manipular.
// El '$' al principio es una convención (no obligatoria) para indicar que la variable contiene un elemento del DOM.
// 'document.getElementById(...)' busca un elemento en el HTML por su 'id'.
const $app = document.getElementById('app'); // El contenedor principal donde cargaremos las vistas.
const $logout = document.getElementById('cerrarSessionLink'); // El enlace de "Cerrar sesión".
const $navLogin = document.getElementById('navLogin'); // El enlace de "Iniciar sesión".
const $navRegister = document.getElementById('navRegister'); // El enlace de "Registrarme".
const $navCrud = document.getElementById('navCrud'); // El enlace para ir al CRUD.

// --- MANEJO DE AUTENTICACIÓN (SESIÓN) ---
// Usamos 'localStorage', que es una pequeña "caja de almacenamiento" en el navegador
// que persiste incluso si cierras la pestaña. Es útil para recordar si un usuario ha iniciado sesión.

// 'isAuth' es una función corta que revisa si existe una clave llamada 'auth' en localStorage.
// '!!' es un truco para convertir cualquier valor a un booleano (true o false).
// Si 'localStorage.getItem('auth')' devuelve algo (el usuario), será 'true'. Si devuelve 'null' (nada), será 'false'.
const isAuth = () => !!localStorage.getItem('auth');

// 'setAuth' guarda los datos del usuario en localStorage.
// 'JSON.stringify(u)' convierte el objeto de usuario 'u' a un texto en formato JSON para poder guardarlo.
// Después de guardar, llama a 'updateNav()' para actualizar los botones del menú.
const setAuth = (u) => { localStorage.setItem('auth', JSON.stringify(u)); updateNav(); };

// 'logout' elimina la clave 'auth' de localStorage, cerrando efectivamente la sesión.
// Luego llama a 'updateNav()' para que el menú refleje que ya no hay sesión.
const logout = () => { localStorage.removeItem('auth'); updateNav(); };

// 'updateNav' actualiza la visibilidad de los enlaces de navegación.
function updateNav() {
  const auth = isAuth(); // Llama a isAuth() para saber si hay sesión.
  // El operador ternario (condición ? valor_si_true : valor_si_false) es una forma corta de un 'if/else'.
  // Si 'auth' es true, muestra el enlace de logout/crud ('inline-block'). Si es false, lo oculta ('none').
  if ($logout) $logout.style.display = auth ? 'inline-block' : 'none';
  // A la inversa para los enlaces de login/register.
  if ($navLogin) $navLogin.style.display = auth ? 'none' : 'inline-block';
  if ($navRegister) $navRegister.style.display = auth ? 'none' : 'inline-block';
  if ($navCrud) $navCrud.style.display = auth ? 'inline-block' : 'none';
}

// --- CONFIGURACIÓN DE VISTAS Y RUTAS ---

// 'VIEWS' es un objeto que funciona como un mapa. Asocia un nombre de ruta con la ruta real del archivo HTML parcial.
const VIEWS = {
  login: 'pages/iniciar-sesion.html',
  register: 'pages/registrarse.html',
  crud: 'formulario.html'
};

// --- FUNCIONES DEL ENRUTADOR (ROUTER) ---

// 'routeNow' obtiene la ruta actual del hash de la URL (lo que está después del '#').
// La limpia para que siempre empiece con '/' y esté en minúsculas.
// Ejemplo: si la URL es misitio.com/#/CRUD, esto devolverá '/crud'.
function routeNow() { return ('/' + (location.hash.replace(/^#\/?/, '') || '')).toLowerCase(); }

// 'go' es una función para navegar a una nueva ruta. Simplemente cambia el hash de la URL,
// lo que automáticamente disparará el evento 'hashchange' que escucharemos más abajo.
function go(path) { location.hash = path; }

// 'load' es la función que carga una vista parcial en el <div id="app">.
// 'async' indica que usará 'await' adentro.
// Recibe la ruta de la vista ('view') y una función opcional 'after' que se ejecutará después de cargar.
async function load(view, after) {
  // 'fetch' es la API del navegador para hacer peticiones de red (como pedir un archivo).
  // 'await' espera a que la petición termine.
  const res = await fetch(view, { cache: 'no-cache' }); // 'no-cache' asegura que siempre pida la versión más nueva del archivo.
  // Si la respuesta no fue exitosa (ej: error 404, no se encontró el archivo)...
  if (!res.ok) {
    // Muestra un mensaje de error en la app.
    $app.innerHTML = `<p style="color:#b91c1c;padding:16px">Vista no encontrada: <code>${view}</code></p>`;
    console.error('404 view', view); // Y en la consola del desarrollador.
    return; // Termina la función.
  }

  // 'await res.text()' espera a obtener el contenido del archivo HTML como texto.
  // '$app.innerHTML = ...' reemplaza todo el contenido del <div id="app"> con el HTML que acabamos de cargar.
  $app.innerHTML = await res.text();

  // 'after?.()' ejecuta la función 'after' si existe. El '?.' es "optional chaining",
  // previene un error si 'after' es nulo o indefinido.
  // Usamos esto para ejecutar el código específico de la vista (ej: 'bindLogin') DESPUÉS de que su HTML esté en la página.
  after?.();
}

// --- LÓGICA DE CADA VISTA (BINDING) ---

// 'bindLogin' se ejecuta después de cargar la vista de login.
function bindLogin() {
  const form = document.getElementById('login-form'); // Busca el formulario de login.
  if (!form) return; // Si no lo encuentra, no hace nada.
  // 'addEventListener' "escucha" un evento en un elemento. Aquí, escuchamos el evento 'submit' del formulario.
  form.addEventListener('submit', (e) => {
    e.preventDefault(); // ¡MUY IMPORTANTE! Evita que el formulario recargue la página, que es el comportamiento por defecto.

    // Obtenemos los valores de los campos de email y contraseña.
    const email = document.getElementById('email').value.trim().toLowerCase();
    const password = document.getElementById('password').value;

    // --- LÓGICA DE AUTENTICACIÓN LOCAL (SIN BACKEND) ---
    // En tu proyecto, esta parte es local, pero podría cambiarse para llamar a una API.
    // Obtenemos los usuarios guardados en localStorage.
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    const user = users[email]; // Buscamos un usuario con ese email.

    // Si el usuario no existe o la contraseña no coincide...
    if (!user || user.password !== password) {
      alert('Correo o contraseña incorrectos'); // Mostramos un error.
      return; // Y detenemos la función.
    }

    // Si todo está bien, guardamos la sesión.
    setAuth({ email, nombre: user.nombre });
    go('/crud'); // Y navegamos a la página del CRUD.
  });
}

// 'bindRegister' funciona de manera muy similar a 'bindLogin', pero para el formulario de registro.
function bindRegister() {
  const form = document.getElementById('Register');
  if (!form) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    // Obtenemos todos los valores del formulario.
    const nombre = document.getElementById('Nombre').value.trim();
    const correo = document.getElementById('correoelectronico').value.trim().toLowerCase();
    const pass = document.getElementById('Contraseña').value;
    const pass2 = document.getElementById('correctpassword').value;

    // Validaciones simples.
    if (pass.length < 6) { alert('La contraseña debe tener al menos 6 caracteres'); return; }
    if (pass !== pass2) { alert('Las contraseñas no coinciden'); return; }

    // Obtenemos los usuarios de localStorage.
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    if (users[correo]) { alert('Ese correo ya está registrado'); return; } // Verificamos si el correo ya existe.

    // Si es un usuario nuevo, lo guardamos en el objeto 'users'.
    users[correo] = { nombre, password: pass };
    // Volvemos a guardar el objeto 'users' completo en localStorage.
    localStorage.setItem('users', JSON.stringify(users));

    // Iniciamos sesión automáticamente para el nuevo usuario.
    setAuth({ email: correo, nombre });
    go('/crud'); // Y lo llevamos a la página del CRUD.
  });
}

// 'bindCrud' se ejecuta después de cargar la vista del CRUD ('formulario.html').
function bindCrud() {
  // Esta función actúa como un puente. Busca una función global llamada 'initCrud'
  // que está definida en 'script.js' y la ejecuta.
  // Esto mantiene la lógica del router separada de la lógica específica del CRUD.
  if (typeof window.initCrud === 'function') window.initCrud();
  else if (typeof window.cargarUsuarios === 'function') window.cargarUsuarios();
}

// --- EL OBJETO DE RUTAS ---
// Este objeto es el corazón del enrutador. Asocia cada ruta (la clave, ej: '/iniciar-sesion')
// con la función que se debe ejecutar cuando el usuario navega a esa ruta.
const routes = {
  // Ruta raíz ('/').
  '/': () => go(isAuth() ? '/crud' : '/iniciar-sesion'), // Si hay sesión, va a '/crud', si no, a '/iniciar-sesion'.

  // Ruta de inicio de sesión.
  '/iniciar-sesion': () => {
    if (isAuth()) return go('/crud'); // Si ya hay sesión, no lo dejamos entrar aquí y lo redirigimos.
    load(VIEWS.login, bindLogin); // Carga la vista 'login' y después ejecuta 'bindLogin'.
  },

  // Ruta de registro.
  '/registrarse': () => {
    if (isAuth()) return go('/crud'); // Igualmente, si ya hay sesión, lo redirigimos.
    load(VIEWS.register, bindRegister); // Carga la vista 'register' y después ejecuta 'bindRegister'.
  },

  // Ruta del CRUD.
  '/crud': () => {
    if (!isAuth()) return go('/iniciar-sesion'); // Si NO hay sesión, lo mandamos a iniciar sesión. ¡Protegemos la ruta!
    load(VIEWS.crud, bindCrud); // Carga la vista 'crud' y después ejecuta 'bindCrud'.
  },

  // Ruta para cerrar sesión.
  '/cerrar_session': () => {
    logout(); // Llama a la función que borra los datos de sesión.
    go('/iniciar-sesion'); // Y lo redirige a la página de login.
  }
};

// --- INICIALIZACIÓN DEL ENRUTADOR ---

// Creamos una función para manejar el cambio de ruta.
const router = () => {
  updateNav(); // Primero, actualizamos el menú de navegación.
  const currentRoute = routeNow(); // Obtenemos la ruta actual.
  // Buscamos la función correspondiente a la ruta actual en nuestro objeto 'routes'.
  // Si no la encuentra (ej: una URL inválida), usa la función de la ruta raíz ('/').
  const handler = routes[currentRoute] || routes['/'];
  handler(); // Ejecutamos la función encontrada.
}

// 'window.addEventListener(...)' registra una función para que se ejecute cuando ocurra un evento.
// 'hashchange': se dispara cada vez que la parte del '#' en la URL cambia.
window.addEventListener('hashchange', router);

// 'DOMContentLoaded': se dispara una sola vez, cuando el HTML inicial ('index.html') ha sido completamente cargado y analizado.
// Esto asegura que nuestro enrutador se ejecute por primera vez al cargar la página.
window.addEventListener('DOMContentLoaded', router);