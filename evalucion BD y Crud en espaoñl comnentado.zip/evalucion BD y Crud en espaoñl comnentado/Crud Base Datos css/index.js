//Este es el cerebro del backend. Es un servidor web que espera peticiones del frontend (el navegador). Cuando llega una petición (como "dame todos los usuarios" o "guarda este nuevo usuario"), este archivo la procesa, habla con la base de datos (usando database.js) y envía una respuesta.



//  (Backend) — Servidor Express + rutas REST (nuestra API)

// Importamos la librería 'express'. Express es un framework (un conjunto de herramientas)
// que hace súper fácil crear servidores web y APIs en Node.js.
import express from 'express';
// Importamos nuestro 'pool' de conexiones que creamos en 'database.js'.
// El './' significa que el archivo está en la misma carpeta que 'index.js'.
import pool from './database.js';
// Importamos 'cors', un middleware (un "intermediario") que permite que nuestro servidor
// acepte peticiones desde un origen diferente (por ejemplo, desde tu frontend que corre en otra dirección o puerto).
// Sin esto, el navegador bloquearía las peticiones por seguridad.
import cors from "cors";

// Estas son utilidades de Node.js para trabajar con rutas de archivos.
import path from "path";
import { fileURLToPath } from "url"; // Nos ayuda a obtener la ruta del archivo actual en el formato que necesitamos.

// Le pasamos esa URL ('file:///...') a nuestro traductor fileURLToPath.
// El traductor la convierte a una ruta de archivo normal.
const __filename = fileURLToPath(import.meta.url);

//Ahora que tenemos una ruta limpia en __filename, usamos nuestra caja de herramientas path.
// Le pasamos la ruta del archivo a la herramienta path.dirname().
//Esta herramienta mira la ruta 'c:\proyecto\crud\index.js' y devuelve solo la parte del directorio (la carpeta).
// La variable __dirname ahora contiene: 'c:\proyecto\crud' (¡recreamos el antiguo __dirname!).
const __dirname = path.dirname(__filename);

// 'const app = express();' es como decir: "Ok, Express, créame una nueva aplicación de servidor".
// La variable 'app' será nuestro servidor, al que le añadiremos toda la lógica.


const app = express();



/// ---------------------------------

// 'app.use(...)' se usa para añadir "middlewares" a Express. Un middleware es una función
// que se ejecuta en cada petición antes de que llegue a nuestras rutas.
// Aquí, le decimos a Express que sirva archivos estáticos (como HTML, CSS, imágenes
// desde una carpeta llamada 'public'. No es obligatorio, pero es una buena práctica.

//express.static(...): Es un middleware que viene incluido en Express. Su única función es buscar archivos en el sistema de archivos del servidor.
app.use(express.static(path.join(__dirname, "pages")));

// Este middleware es CRUCIAL. Le dice a Express cómo entender los datos que vienen en formato JSON.
// Cuando el frontend envía datos (como un nuevo usuario), los envía como un texto JSON.
// Esto lo convierte en un objeto de JavaScript que podemos usar fácilmente en 'req.body'.
app.use(express.json());
// Este middleware es para entender datos que vienen de formularios HTML tradicionales.
// Permite que req.body entienda datos enviados desde formularios.
app.use(express.urlencoded({ extended: true }));

// Usamos el middleware 'cors' que importamos.
// 'origin: "*"' es una configuración muy abierta que dice: "Acepta peticiones de CUALQUIER origen".
// Para un proyecto real, aquí deberías poner la dirección de tu frontend (ej: 'http://localhost:8080').
//CORS = sistema de seguridad del navegador.
// origin: "*" → significa “permito que cualquier página web (cualquier dominio) me llame”.
// * esto podira ser cambiado por el dominio (ej: https://mitienda.com) para mayor seguridad?

app.use(cors({
  origin: "*"
}));

// --- DEFINICIÓN DE RUTAS DE LA API (ENDPOINTS) ---
// Una ruta es una URL específica que nuestro servidor sabe cómo responder.

// ----------------------------------------------------
// RUTA PARA CREAR un usuario nuevo (CREATE del CRUD)
// ----------------------------------------------------
// 'app.post' define que esta ruta responde a peticiones con el método HTTP POST.
// POST se usa convencionalmente para crear nuevos recursos.
// '/usuarios' es la URL.
// 'async (req, res) => { ... }' es la función que maneja la petición.
// 'async' nos permite usar 'await' adentro.
// 'req' (request) es un objeto con toda la información de la petición que llega del frontend.
// 'res' (response) es un objeto que usamos para enviar una respuesta de vuelta al frontend.
app.post("/usuarios", async (req, res) => {
  // 'const { ... } = req.body;' es "desestructuración". Es una forma corta de sacar
  // las propiedades del objeto 'req.body' y guardarlas en variables con el mismo nombre.
  // 'req.body' contiene los datos JSON que el frontend nos envió.
  const { nombre, identificacion, direccion, telefono, correo } = req.body;

  // 'const [result] = await pool.query(...)'
  // 'await' pausa la función aquí hasta que la consulta a la base de datos termine.
  // 'pool.query()' ejecuta un comando SQL.
  // El primer argumento es el comando SQL. 'INSERT INTO...' es para añadir una nueva fila.
  // Los '?' son MARCADORES. Son una medida de seguridad MUY IMPORTANTE para prevenir "Inyección SQL".
  // El segundo argumento es un array '[]' con los valores que reemplazarán a los '?' en orden.
  //[result] → toma el primer valor del array y lo guarda en la variable result. 
  const [result] = await pool.query(
    "INSERT INTO usuarios (nombre, identificacion, direccion, telefono, correo) VALUES (?, ?, ?, ?, ?)",
    [nombre, identificacion, direccion, telefono, correo]
  );

  // 'res.json(...)' envía una respuesta al frontend en formato JSON.
  // Le devolvemos un objeto con el 'id' del usuario recién creado (que nos da 'result.insertId')
  // y los datos que guardamos, para confirmar que todo salió bien.
  res.json({ id: result.insertId, nombre, identificacion, direccion, telefono, correo});
});

// ----------------------------------------------------
// RUTA PARA LEER todos los usuarios (READ del CRUD)
// ----------------------------------------------------
// 'app.get' responde a peticiones HTTP GET. GET se usa para solicitar datos.
app.get("/usuarios", async (req, res) => {
  // 'SELECT * FROM usuarios' es el comando SQL para seleccionar todas las columnas ('*') de todas las filas en la tabla 'usuarios'.
  const [rows] = await pool.query("SELECT * FROM usuarios");
  // Enviamos las filas ('rows') que obtuvimos de la base de datos como respuesta JSON.
  res.json(rows);
});

// ----------------------------------------------------
// RUTA PARA LEER UN SOLO usuario por su ID (READ del CRUD)
// ----------------------------------------------------
// '/usuarios/:id' es una ruta con un parámetro. Express entenderá que lo que venga
// después de '/usuarios/' es un valor variable que llamaremos 'id'.
app.get("/usuarios/:id", async (req, res) => {
  // Podemos acceder a ese parámetro con 'req.params.id'.
  const [rows] = await pool.query("SELECT * FROM usuarios WHERE id = ?", [req.params.id]);
  // Verificamos si la consulta devolvió algún usuario.
  // Si 'rows.length' es 0, significa que no se encontró un usuario con ese 'id'.
  if (rows.length === 0) return res.status(404).json({ message: "User not found" });
  // 'res.status(404)' envía un código de estado "No Encontrado". Es una buena práctica.
  // Si encontramos al usuario, devolvemos solo el primer resultado (rows[0]), porque el 'id' es único.
  res.json(rows[0]);
});

// ----------------------------------------------------
// RUTA PARA ACTUALIZAR un usuario (UPDATE del CRUD)
// ----------------------------------------------------
// 'app.put' responde a peticiones HTTP PUT. PUT se usa para actualizar un recurso existente.
app.put("/usuarios/:id", async (req, res) => {
  // Obtenemos los nuevos datos del cuerpo de la petición (lo que el usuario modificó en el formulario).
  const { nombre, identificacion, direccion, telefono, correo } = req.body;

  // Ejecutamos el comando SQL 'UPDATE'. 'SET' especifica qué columnas cambiar.
  // 'WHERE id = ?' es crucial para asegurarnos de que solo actualizamos al usuario correcto.
  const [result] = await pool.query(
    "UPDATE usuarios SET nombre = ?, identificacion = ?, direccion = ?, telefono = ?, correo = ? WHERE id = ?",
    // El último valor en el array corresponde al último '?' en la consulta (el 'id').
    [nombre, identificacion, direccion, telefono, correo, req.params.id]
  );

  // Devolvemos un JSON que informa cuántas filas fueron afectadas/cambiadas por la consulta.
  res.json({ changedRows: result.affectedRows });
});

// ----------------------------------------------------
// RUTA PARA BORRAR un usuario (DELETE del CRUD)
// ----------------------------------------------------
// 'app.delete' responde a peticiones HTTP DELETE. DELETE se usa para eliminar un recurso.
app.delete("/usuarios/:id", async (req, res) => {
  // Ejecutamos el comando SQL 'DELETE'. 'WHERE id = ?' es fundamental para no borrar toda la tabla.
  const [result] = await pool.query("DELETE FROM usuarios WHERE id = ?", [req.params.id]);
  // Devolvemos cuántas filas fueron eliminadas.
  res.json({ deletedRows: result.affectedRows });
});

// 'app.listen' inicia el servidor y lo pone a "escuchar" peticiones en un puerto específico.
// El puerto 3000 es comúnmente usado para desarrollo.
// La función '() => console.log(...)' se ejecuta una sola vez cuando el servidor arranca exitosamente.
app.listen(3000, () => console.log("Servidor en http://localhost:3000"));