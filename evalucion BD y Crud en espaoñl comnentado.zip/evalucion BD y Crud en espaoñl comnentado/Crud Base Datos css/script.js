//Este archivo contiene toda la lógica de la página del CRUD. Se encarga de hablar con tu API del backend (creada en index.js). Pide la lista de usuarios, la muestra en una tabla, y maneja los formularios para crear, editar y eliminar usuarios, enviando las peticiones correspondientes al backend.



// script.js (Frontend) — Lógica del CRUD en el navegador.

// 'window.initCrud = function(){ ... }'
// Creamos una función y la asignamos a 'window'. Esto la hace "global", es decir,
// accesible desde cualquier otro script, como nuestro 'routes.js'.
// 'routes.js' llama a esta función cuando carga la vista del CRUD.
// Toda la lógica del CRUD está dentro de esta función para mantenerla organizada y evitar que se ejecute en otras páginas.
window.initCrud = function() {

  // 'const apiURL = "..."' define la URL base de nuestro backend.
  // Todas las peticiones al servidor usarán esta variable.
  const apiURL = "http://localhost:3000/usuarios";

  // --- FUNCIÓN PARA CARGAR Y MOSTRAR USUARIOS (READ) ---
  // 'async' porque usará 'await' para esperar la respuesta del servidor.
  async function cargarUsuarios() {

    // 'const res = await fetch(apiURL);'
    // 'fetch' hace una petición de red. Por defecto, si no especificamos el método, es un GET.
    // Esto hace una petición GET a 'http://localhost:3000/usuarios'.
    // 'await' pausa la ejecución hasta que el servidor responda.
    const res = await fetch(apiURL);
    // 'const usuarios = await res.json();'
    // 'res.json()' toma la respuesta del servidor (que es un texto en formato JSON)
    // y la convierte en un array de objetos de JavaScript que podemos usar.
    const usuarios = await res.json();

    // Buscamos el cuerpo de la tabla en el HTML ('formulario.html').
    const tbody = document.getElementById("tablaUsuarios");
    if (!tbody) return; // Si no existe la tabla, no continuamos.

    // Limpiamos la tabla para no acumular usuarios si llamamos a la función varias veces.
    tbody.innerHTML = "";
    // 'usuarios.forEach(u => { ... })' recorre cada usuario 'u' en el array 'usuarios'.
    usuarios.forEach(u => {

      // Por cada usuario, construimos una fila de tabla ('<tr>') como un string de HTML.
      // Usamos "template literals" (comillas invertidas ``) que nos permiten insertar variables
      // fácilmente con la sintaxis `${...}`.
      // 'u.direccion || ""' es un truco: si 'u.direccion' existe, lo usa. Si es nulo o indefinido, usa una cadena vacía "".
      // Los botones 'Editar' y 'Eliminar' tienen un evento 'onclick' que llama a funciones globales
      // pasándoles el 'id' del usuario de esa fila.
      tbody.innerHTML += `
        <tr>
          <td>${u.id}</td>
          <td>${u.nombre}</td>
          <td>${u.identificacion}</td>
          <td>${u.direccion || ""}</td>
          <td>${u.telefono || ""}</td>
          <td>${u.correo || ""}</td>
          <td>
            <button onclick="editarUsuario(${u.id})">Editar</button>
            <button onclick="eliminarUsuario(${u.id})">Eliminar</button>
          </td>
        </tr>
      `; // '+= significa que añade esta nueva fila al contenido que ya existe en 'tbody'.
    });
  }

  // Hacemos esta función global para poder llamarla desde otras partes si es necesario.
  window.cargarUsuarios = cargarUsuarios;

  // --- LÓGICA PARA CREAR UN NUEVO USUARIO (CREATE) ---
  const formCrear = document.getElementById("formCrear"); // Obtenemos el formulario de creación.
  if (formCrear) {
    // Escuchamos el evento 'submit' de este formulario.
    formCrear.addEventListener("submit", async e => {
      e.preventDefault(); // Evitamos que la página se recargue.

      // 'new FormData(e.target)' crea un objeto especial con los datos del formulario.
      // 'Object.fromEntries(...)' lo convierte en un objeto JavaScript normal.
      // Ejemplo: { nombre: "Juan", identificacion: "123", ... }
      const data = Object.fromEntries(new FormData(e.target));

      // Hacemos una petición POST al servidor para crear el usuario.
      const resp = await fetch(apiURL, {
        method: "POST", // Especificamos el método HTTP.
        headers: { "Content-Type": "application/json" }, // Le decimos al servidor que le estamos enviando datos en formato JSON.
        body: JSON.stringify(data) // Convertimos nuestro objeto 'data' a un string JSON para enviarlo.
      });

      if (!resp.ok) { alert("Error al crear"); return; } // Si el servidor respondió con un error, avisamos al usuario.

      e.target.reset(); // Limpia los campos del formulario.
      cargarUsuarios(); // Vuelve a cargar la lista de usuarios para que el nuevo aparezca inmediatamente.
    });
  }

  // --- LÓGICA PARA EDITAR UN USUARIO (UPDATE) ---

  // Hacemos la función 'editarUsuario' global para poder llamarla desde el 'onclick' del botón.
  window.editarUsuario = async function(id) {
    // Primero, pedimos al servidor los datos del usuario específico que se va a editar.
    // Hacemos un GET a 'http://localhost:3000/usuarios/123' (si el id es 123).
    const res = await fetch(`${apiURL}/${id}`);
    const u = await res.json(); // Convertimos la respuesta a un objeto.

    // Buscamos el formulario de edición en el HTML.
    const form = document.getElementById("formEditar");
    if (!form) return;
    form.style.display = "block"; // Lo hacemos visible (estaba oculto).

    // Rellenamos los campos del formulario de edición con los datos del usuario que recibimos.
    form.id.value = u.id; // Guardamos el 'id' en el campo oculto.
    form.nombre.value = u.nombre;
    form.identificacion.value = u.identificacion;
    form.direccion.value = u.direccion || '';
    form.telefono.value = u.telefono || '';
    form.correo.value = u.correo || '';
  };

  // Ahora, añadimos la lógica para cuando se envía el formulario de edición.
  const formEditar = document.getElementById("formEditar");
  if (formEditar) {
    formEditar.addEventListener("submit", async e => {
      e.preventDefault(); // Evitamos recarga.

      const data = Object.fromEntries(new FormData(e.target)); // Obtenemos los datos actualizados del formulario.

      const id = data.id; // Guardamos el id del usuario.
      delete data.id; // Lo borramos del objeto 'data' porque no queremos enviar el 'id' dentro del cuerpo (body) de la petición.

      // Hacemos una petición PUT al servidor para actualizar el usuario.
      const resp = await fetch(`${apiURL}/${id}`, {
        method: "PUT", // Usamos el método PUT para actualizar.
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data) // Enviamos los nuevos datos.
      });

      if (!resp.ok) { alert("Error al actualizar"); return; }

      e.target.style.display = "none"; // Ocultamos el formulario de edición de nuevo.
      e.target.reset(); // Limpiamos el formulario.
      cargarUsuarios(); // Recargamos la lista para ver los cambios.
    });
  }

  // --- LÓGICA PARA ELIMINAR UN USUARIO (DELETE) ---

  // Hacemos la función 'eliminarUsuario' global.
  window.eliminarUsuario = async function(id) {
    // 'confirm' muestra una ventana de confirmación al usuario (Aceptar/Cancelar).
    // Si el usuario presiona "Cancelar", la función se detiene aquí.
    if (!confirm("¿Seguro que deseas eliminar este usuario?")) return;

    // Hacemos una petición DELETE al servidor para eliminar el usuario.
    await fetch(`${apiURL}/${id}`, { method: "DELETE" });

    // Recargamos la lista para que el usuario eliminado desaparezca.
    cargarUsuarios();
  };


  // --- EJECUCIÓN INICIAL ---
  // Cuando 'initCrud' se llama por primera vez...
  // Verificamos si el elemento 'tablaUsuarios' existe en el DOM.
  // Si existe, significa que estamos en la página del CRUD,
  // así que llamamos a 'cargarUsuarios()' para llenar la tabla por primera vez.
  if (document.getElementById("tablaUsuarios")) {
      cargarUsuarios();
  }
};

// Esta línea es un seguro. Si por alguna razón 'routes.js' carga el script
// pero la vista del CRUD ya estaba presente, esto asegura que la lógica se ejecute.
if (document.getElementById("tablaUsuarios")) {
  window.initCrud();
}