//Este archivo es como el enchufe de tu aplicación a la base de datos. Su única misión es crear una conexión con MySQL y dejarla lista para que otros archivos la usen.



// (Backend) — Conexión a un "pool" o grupo de conexiones de MySQL.
// Un "pool" es como tener varias líneas telefónicas listas para llamar a la base de datos.
// En lugar de crear una nueva conexión cada vez que la necesitas (lo cual es lento),
// simplemente tomas una que ya está abierta del "pool".

// 'import' es la palabra clave en JavaScript moderno para traer código desde otro archivo o librería.
// Aquí, estamos importando la librería 'mysql2/promise'.
// 'mysql2' es un driver (un controlador) mejorado para conectar Node.js con MySQL.
// '/promise' es una versión especial de la librería que nos permite usar 'async/await',
// que es una forma más moderna y fácil de manejar operaciones que toman tiempo (como consultar una base de datos).
import mysql from "mysql2/promise";

// 'const' se usa para declarar una variable que no va a cambiar su valor. La llamamos 'pool'.
// 'mysql.createPool()' es la función de la librería que crea nuestro grupo de conexiones.
// Le pasamos un objeto de configuración, que se define con las llaves '{}'.
const pool = mysql.createPool({
  // 'host': La dirección donde está tu servidor de base de datos. 'localhost' significa "en esta misma computadora".
  host: "localhost",
  // 'user': El nombre de usuario para entrar a MySQL. 'root' es el usuario administrador por defecto.
  user: "root",
  // 'password': La contraseña de ese usuario.
  password: "Qwe.123*",
  // 'database': El nombre de la base de datos específica a la que nos queremos conectar dentro de MySQL.
  database: "Bibliosoft"
});

// 'export default' es la forma de decir: "Hey, el resultado principal de este archivo es la variable 'pool'".
// Esto permite que otros archivos (como 'index.js') puedan 'importar' la variable 'pool' y usarla
// para hacer consultas a la base de datos.
export default pool;